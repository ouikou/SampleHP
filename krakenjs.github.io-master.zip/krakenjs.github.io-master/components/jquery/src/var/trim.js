define(function() {
	return "".trim;
});
