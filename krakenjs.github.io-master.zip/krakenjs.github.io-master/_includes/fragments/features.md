## The kraken suite

Kraken is a secure and scalable layer that extends [express](http://expressjs.com/) by providing structure and convention.
Though kraken is the main pillar of our framework, the following modules can also be used independently: