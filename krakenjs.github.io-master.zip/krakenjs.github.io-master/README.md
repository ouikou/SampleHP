krakenjs.com
============

Lead Maintainer: [Matt Edelman](https://github.com/grawk/)  

This is the source code for krakenjs.com


## Setup

1. Clone this repo
2. Make sure you have Jekyll setup per [GitHub's instructions](https://help.github.com/articles/using-jekyll-with-pages)
3. Run `bundle exec jekyll serve  --watch` from within your repo to generate the pages
