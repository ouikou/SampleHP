---
title: Announcing our new blog
layout: blog
---

We've been remiss for some time about announcements. We've always used [our twitter account] for announcements and information about the project, but that doesn't lend itself well to release notes, change logs and more thoughtful pieces.

Today, we thought we'd fix that.

[our twitter account]: https://twitter.com/kraken_js
